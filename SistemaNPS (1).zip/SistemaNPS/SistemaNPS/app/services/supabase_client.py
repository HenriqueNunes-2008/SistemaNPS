import os
from dotenv import load_dotenv
from supabase import create_client

load_dotenv()

SUPABASE_URL = "https://hevygonwpitpdlgtlmza.supabase.co"
SUPABASE_SERVICE_ROLE_KEY = "sb_secret_wJiuRlzxkkINwFgIexpicQ_WFULD2lU"

if not SUPABASE_URL or not SUPABASE_SERVICE_ROLE_KEY:
    raise RuntimeError("Variáveis SUPABASE não configuradas")

supabase = create_client(
    SUPABASE_URL,
    SUPABASE_SERVICE_ROLE_KEY
)
