import base64
import hmac
import os
import time

from fastapi import APIRouter, Request, HTTPException, Response, Form
from fastapi.templating import Jinja2Templates
from fastapi.responses import HTMLResponse
from fastapi.responses import RedirectResponse
from app.services.supabase_client import supabase

router = APIRouter()
templates = Jinja2Templates(directory="app/templates", auto_reload=True)

_SESSION_COOKIE = "nps_session"
_SESSION_TTL_SECONDS = 60 * 60 * 12
_APP_SECRET = os.getenv("APP_SECRET")
if not _APP_SECRET:
    raise RuntimeError("Variavel APP_SECRET nao configurada no .env")
_ADMIN_EMAIL = (os.getenv("ADMIN_EMAIL") or "").strip().lower()
_ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD") or ""


def _sign_session(payload: str) -> str:
    sig = hmac.new(
        _APP_SECRET.encode("utf-8"),
        payload.encode("utf-8"),
        "sha256"
    ).hexdigest()
    token = f"{payload}.{sig}".encode("utf-8")
    return base64.urlsafe_b64encode(token).decode("utf-8")


def _unsign_session(token: str) -> str | None:
    try:
        raw = base64.urlsafe_b64decode(token.encode("utf-8")).decode("utf-8")
        payload, sig = raw.rsplit(".", 1)
        expected = hmac.new(
            _APP_SECRET.encode("utf-8"),
            payload.encode("utf-8"),
            "sha256"
        ).hexdigest()
        if not hmac.compare_digest(sig, expected):
            return None
        return payload
    except Exception:
        return None


def _build_session(email: str) -> str:
    exp = int(time.time()) + _SESSION_TTL_SECONDS
    payload = f"{email}|{exp}"
    return _sign_session(payload)


def _get_session_email(request: Request) -> str | None:
    token = request.cookies.get(_SESSION_COOKIE)
    if not token:
        return None
    payload = _unsign_session(token)
    if not payload:
        return None
    try:
        email, exp_str = payload.split("|", 1)
        if int(exp_str) < int(time.time()):
            return None
        return email
    except Exception:
        return None


def _require_login(request: Request) -> str | None:
    return _get_session_email(request)


def _extract_storage_path(public_url: str) -> str | None:
    marker = "/storage/v1/object/public/processos/"
    if marker in public_url:
        return public_url.split(marker, 1)[1]
    if public_url.startswith("processos/"):
        return public_url.split("processos/", 1)[1]
    return None


def _download_pdf(url: str) -> bytes:
    path = _extract_storage_path(url)
    if not path:
        raise HTTPException(status_code=400, detail="URL de storage invÃ¡lida")

    res = supabase.storage.from_("processos").download(path)
    if hasattr(res, "error") and res.error:
        raise HTTPException(status_code=502, detail=res.error.message)
    if isinstance(res, dict) and res.get("error"):
        raise HTTPException(status_code=502, detail=res.get("error"))
    return res

@router.get("/", response_class=HTMLResponse)
def login(request: Request):
    return templates.TemplateResponse(
        "login.html",
        {"request": request, "error": None, "success": None}
    )

@router.get("/login", response_class=HTMLResponse)
def login_alias(request: Request):
    return templates.TemplateResponse(
        "login.html",
        {"request": request, "error": None, "success": None}
    )

@router.get("/index", response_class=HTMLResponse)
def index(request: Request):
    if not _require_login(request):
        return RedirectResponse(url="/login", status_code=303)
    return templates.TemplateResponse("Index.html", {"request": request})

@router.get("/cadastro", response_class=HTMLResponse)
def cadastro(request: Request):
    return templates.TemplateResponse(
        "cadastro.html",
        {"request": request, "error": None, "success": None}
    )

@router.get("/termo", response_class=HTMLResponse)
def termo(request: Request):
    if not _require_login(request):
        return RedirectResponse(url="/login", status_code=303)
    return templates.TemplateResponse("TermoAceite.html", {"request": request})


@router.get("/ressalvas", response_class=HTMLResponse)
def ressalvas(request: Request):
    if not _require_login(request):
        return RedirectResponse(url="/login", status_code=303)
    return templates.TemplateResponse("Ressalvas.html", {"request": request})


@router.get("/nps", response_class=HTMLResponse)
def nps(request: Request):
    if not _require_login(request):
        return RedirectResponse(url="/login", status_code=303)
    return templates.TemplateResponse("NPS2System.html", {"request": request})


@router.get("/admin", response_class=HTMLResponse)
def admin(request: Request):
    session_email = _require_login(request)
    if not session_email:
        return RedirectResponse(url="/login", status_code=303)
    if not _ADMIN_EMAIL or session_email != _ADMIN_EMAIL:
        return RedirectResponse(url="/login", status_code=303)
    processos = []
    try:
        res = (
            supabase
            .table("processos")
            .select(
                "codigo,nome_cliente,empresa,cpf,status,status_entrega,"
                "criado_em,atualizado_em,termo_pdf,pdf_ressalvas,pdf_final,nps_nota"
            )
            .order("criado_em", desc=True)
            .execute()
        )

        if hasattr(res, "error") and res.error:
            raise RuntimeError(res.error.message)

        processos = res.data or []
    except Exception:
        # Fallback para schema antigo (antes das novas colunas)
        res = (
            supabase
            .table("processos")
            .select(
                "codigo,nome_cliente,cpf,status,status_entrega,criado_em,"
                "termo_pdf,pdf_ressalvas,pdf_final"
            )
            .order("criado_em", desc=True)
            .execute()
        )
        processos = res.data or []
        for p in processos:
            p.setdefault("empresa", None)
            p.setdefault("nps_nota", None)
            p.setdefault("atualizado_em", None)

    q = (request.query_params.get("q") or "").strip().lower()
    if q:
        processos = [
            p for p in processos
            if q in (p.get("codigo") or "").lower()
            or q in (p.get("nome_cliente") or "").lower()
            or q in (p.get("empresa") or "").lower()
        ]

    notas = [
        p.get("nps_nota") for p in processos
        if isinstance(p.get("nps_nota"), int)
    ]
    negativas = [n for n in notas if n <= 6]
    neutras = [n for n in notas if 7 <= n <= 8]
    positivas = [n for n in notas if n >= 9]

    def media(valores):
        return round(sum(valores) / len(valores), 2) if valores else None

    stats = {
        "total": len(processos),
        "com_termo": len([p for p in processos if p.get("termo_pdf")]),
        "com_ressalvas": len([p for p in processos if p.get("pdf_ressalvas")]),
        "com_nps": len([p for p in processos if p.get("nps_nota") is not None]),
        "media_negativas": media(negativas),
        "media_neutras": media(neutras),
        "media_positivas": media(positivas),
        "count_negativas": len(negativas),
        "count_neutras": len(neutras),
        "count_positivas": len(positivas)
    }

    return templates.TemplateResponse(
        "admin.html",
        {
            "request": request,
            "processos": processos,
            "stats": stats,
            "q": q
        }
    )

@router.get("/user", response_class=HTMLResponse)
def user(request: Request):
    if not _require_login(request):
        return RedirectResponse(url="/login", status_code=303)
    return templates.TemplateResponse("User.html", {"request": request})

@router.get("/nps-motor", response_class=HTMLResponse)
def nps_motor(request: Request):
    if not _require_login(request):
        return RedirectResponse(url="/login", status_code=303)
    return templates.TemplateResponse("NPSMotor.html", {"request": request})


@router.post("/cadastro", response_class=HTMLResponse)
def cadastro_submit(
    request: Request,
    nome: str = Form(...),
    sobrenome: str = Form(...),
    email: str = Form(...),
    password: str = Form(...),
    confirm_password: str = Form(...)
):
    email_norm = email.strip().lower()
    if password != confirm_password:
        return templates.TemplateResponse(
            "cadastro.html",
            {
                "request": request,
                "error": "As senhas nao conferem.",
                "success": None
            }
        )
    try:
        auth_res = supabase.auth.sign_up(
            {
                "email": email_norm,
                "password": password,
                "options": {
                    "data": {
                        "nome": nome.strip(),
                        "sobrenome": sobrenome.strip()
                    }
                }
            }
        )
        if getattr(auth_res, "error", None):
            raise RuntimeError(auth_res.error.message)

        user = getattr(auth_res, "user", None)
        user_id = getattr(user, "id", None) if user else None

        try:
            supabase.table("usuarios").insert(
                {
                    "auth_user_id": user_id,
                    "nome": nome.strip(),
                    "sobrenome": sobrenome.strip(),
                    "email": email_norm
                }
            ).execute()
        except Exception:
            pass
    except Exception:
        return templates.TemplateResponse(
            "cadastro.html",
            {
                "request": request,
                "error": "Nao foi possivel cadastrar. Verifique o email e a senha.",
                "success": None
            }
        )

    return templates.TemplateResponse(
        "cadastro.html",
        {
            "request": request,
            "error": None,
            "success": "Cadastro realizado. Verifique o email se houver confirmacao."
        }
    )


@router.post("/login", response_class=HTMLResponse)
def login_submit(
    request: Request,
    email: str = Form(...),
    password: str = Form(...)
):
    email_norm = email.strip().lower()
    if _ADMIN_EMAIL and _ADMIN_PASSWORD:
        if email_norm == _ADMIN_EMAIL and password == _ADMIN_PASSWORD:
            response = RedirectResponse(url="/admin", status_code=303)
            response.set_cookie(
                _SESSION_COOKIE,
                _build_session(email_norm),
                max_age=_SESSION_TTL_SECONDS,
                httponly=True,
                samesite="lax"
            )
            return response
    try:
        auth_res = supabase.auth.sign_in_with_password(
            {
                "email": email_norm,
                "password": password
            }
        )
        if getattr(auth_res, "error", None):
            raise RuntimeError(auth_res.error.message)
    except Exception as exc:
        message = "Email ou senha invalidos."
        err_text = str(exc).lower()
        if "confirm" in err_text or "verify" in err_text:
            message = "Email ainda nao confirmado. Verifique sua caixa de entrada."
        return templates.TemplateResponse(
            "login.html",
            {
                "request": request,
                "error": message,
                "success": None
            }
        )

    response = RedirectResponse(url="/index", status_code=303)
    response.set_cookie(
        _SESSION_COOKIE,
        _build_session(email_norm),
        max_age=_SESSION_TTL_SECONDS,
        httponly=True,
        samesite="lax"
    )
    return response


@router.get("/logout")
def logout():
    response = RedirectResponse(url="/login", status_code=303)
    response.delete_cookie(_SESSION_COOKIE)
    return response


@router.get("/esqueci", response_class=HTMLResponse)
def forgot_password(request: Request):
    return templates.TemplateResponse(
        "forgot.html",
        {"request": request, "error": None, "success": None}
    )


@router.post("/esqueci", response_class=HTMLResponse)
def forgot_password_submit(
    request: Request,
    email: str = Form(...)
):
    email_norm = email.strip().lower()
    try:
        res = supabase.auth.reset_password_for_email(email_norm)
        if getattr(res, "error", None):
            raise RuntimeError(res.error.message)
    except Exception:
        return templates.TemplateResponse(
            "forgot.html",
            {
                "request": request,
                "error": "Nao foi possivel enviar o email de recuperacao.",
                "success": None
            }
        )

    return templates.TemplateResponse(
        "forgot.html",
        {
            "request": request,
            "error": None,
            "success": "Email de recuperacao enviado. Verifique sua caixa de entrada."
        }
    )


@router.get("/pdf/termo/{codigo}")
def pdf_termo(codigo: str):
    proc = (
        supabase
        .table("processos")
        .select("termo_pdf")
        .eq("codigo", codigo)
        .single()
        .execute()
    )
    if not proc.data or not proc.data.get("termo_pdf"):
        raise HTTPException(status_code=404, detail="PDF do termo nÃ£o encontrado")

    pdf_bytes = _download_pdf(proc.data["termo_pdf"])
    return Response(
        content=pdf_bytes,
        media_type="application/pdf",
        headers={"Content-Disposition": "inline; filename=termo.pdf"}
    )


@router.get("/pdf/ressalvas/{codigo}")
def pdf_ressalvas(codigo: str):
    proc = (
        supabase
        .table("processos")
        .select("pdf_ressalvas")
        .eq("codigo", codigo)
        .single()
        .execute()
    )
    if not proc.data or not proc.data.get("pdf_ressalvas"):
        raise HTTPException(status_code=404, detail="PDF de ressalvas nÃ£o encontrado")

    pdf_bytes = _download_pdf(proc.data["pdf_ressalvas"])
    return Response(
        content=pdf_bytes,
        media_type="application/pdf",
        headers={"Content-Disposition": "inline; filename=ressalvas.pdf"}
    )


@router.get("/pdf/final/{codigo}")
def pdf_final(codigo: str):
    proc = (
        supabase
        .table("processos")
        .select("pdf_final")
        .eq("codigo", codigo)
        .single()
        .execute()
    )
    if not proc.data or not proc.data.get("pdf_final"):
        raise HTTPException(status_code=404, detail="PDF final nÃ£o encontrado")

    pdf_bytes = _download_pdf(proc.data["pdf_final"])
    return Response(
        content=pdf_bytes,
        media_type="application/pdf",
        headers={"Content-Disposition": "inline; filename=entrega_final.pdf"}
    )

@router.get("/.well-known/appspecific/com.chrome.devtools.json")
def chrome_devtools():
    return {}
